from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import pandas as pd
from predict import load_model, predict
from data_processing import preprocess_input

app = FastAPI(title="Handover Failure Prediction API")

model = load_model("model/rf_model.pkl")

class CellInput(BaseModel):
    signal_strength: float
    handover_attempts: int
    throughput: float
    latency: float
    jitter: float
    neighboring_cells: int

@app.post("/predict")
def make_prediction(data: List[CellInput]):
    try:
        df = pd.DataFrame([d.dict() for d in data])
        processed_data = preprocess_input(df)
        preds = predict(model, processed_data)
        return {"predictions": preds.tolist()}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))